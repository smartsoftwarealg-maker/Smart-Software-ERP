import { ModuleWithProviders } from '@angular/core';
import { GoogleChartsConfig } from './types/google-charts-config';
export declare class GoogleChartsModule {
    static forRoot(config?: GoogleChartsConfig): ModuleWithProviders<GoogleChartsModule>;
}
