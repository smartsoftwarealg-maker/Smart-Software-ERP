/// <reference types="@types/google.visualization" />
import { Column, Row } from '../components/chart-base/chart-base.component';
import { Formatter } from '../types/formatter';
export declare class DataTableService {
    create(data: Row[] | undefined, columns?: Column[], formatters?: Formatter[]): google.visualization.DataTable | undefined;
    private getDataAsTable;
    private applyFormatters;
}
