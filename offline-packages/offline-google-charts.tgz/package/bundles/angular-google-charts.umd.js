(function (global, factory) {
    typeof exports === 'object' && typeof module !== 'undefined' ? factory(exports, require('rxjs'), require('@angular/core'), require('rxjs/operators')) :
    typeof define === 'function' && define.amd ? define('angular-google-charts', ['exports', 'rxjs', '@angular/core', 'rxjs/operators'], factory) :
    (global = typeof globalThis !== 'undefined' ? globalThis : global || self, factory(global['angular-google-charts'] = {}, global.rxjs, global.ng.core, global.rxjs.operators));
}(this, (function (exports, rxjs, i0, operators) { 'use strict';

    function _interopNamespace(e) {
        if (e && e.__esModule) return e;
        var n = Object.create(null);
        if (e) {
            Object.keys(e).forEach(function (k) {
                if (k !== 'default') {
                    var d = Object.getOwnPropertyDescriptor(e, k);
                    Object.defineProperty(n, k, d.get ? d : {
                        enumerable: true,
                        get: function () {
                            return e[k];
                        }
                    });
                }
            });
        }
        n['default'] = e;
        return Object.freeze(n);
    }

    var i0__namespace = /*#__PURE__*/_interopNamespace(i0);

    /// <reference path="./types.ts" />
    var ChartEditorRef = /** @class */ (function () {
        function ChartEditorRef(editor) {
            this.editor = editor;
            this.doneSubject = new rxjs.Subject();
            this.addEventListeners();
        }
        /**
         * Gets an observable that is notified when the dialog is saved.
         * Emits either the result if the dialog was saved or `null` if editing was cancelled.
         */
        ChartEditorRef.prototype.afterClosed = function () {
            return this.doneSubject.asObservable();
        };
        /**
         * Stops editing the chart and closes the dialog.
         */
        ChartEditorRef.prototype.cancel = function () {
            this.editor.closeDialog();
        };
        ChartEditorRef.prototype.addEventListeners = function () {
            var _this = this;
            google.visualization.events.addOneTimeListener(this.editor, 'ok', function () {
                google.visualization.events.removeAllListeners(_this.editor);
                var updatedChartWrapper = _this.editor.getChartWrapper();
                _this.doneSubject.next(updatedChartWrapper);
                _this.doneSubject.complete();
            });
            google.visualization.events.addOneTimeListener(this.editor, 'cancel', function () {
                google.visualization.events.removeAllListeners(_this.editor);
                _this.doneSubject.next(null);
                _this.doneSubject.complete();
            });
        };
        return ChartEditorRef;
    }());

    exports.ChartType = void 0;
    (function (ChartType) {
        ChartType["AnnotationChart"] = "AnnotationChart";
        ChartType["AreaChart"] = "AreaChart";
        ChartType["Bar"] = "Bar";
        ChartType["BarChart"] = "BarChart";
        ChartType["BubbleChart"] = "BubbleChart";
        ChartType["Calendar"] = "Calendar";
        ChartType["CandlestickChart"] = "CandlestickChart";
        ChartType["ColumnChart"] = "ColumnChart";
        ChartType["ComboChart"] = "ComboChart";
        ChartType["PieChart"] = "PieChart";
        ChartType["Gantt"] = "Gantt";
        ChartType["Gauge"] = "Gauge";
        ChartType["GeoChart"] = "GeoChart";
        ChartType["Histogram"] = "Histogram";
        ChartType["Line"] = "Line";
        ChartType["LineChart"] = "LineChart";
        ChartType["Map"] = "Map";
        ChartType["OrgChart"] = "OrgChart";
        ChartType["Sankey"] = "Sankey";
        ChartType["Scatter"] = "Scatter";
        ChartType["ScatterChart"] = "ScatterChart";
        ChartType["SteppedAreaChart"] = "SteppedAreaChart";
        ChartType["Table"] = "Table";
        ChartType["Timeline"] = "Timeline";
        ChartType["TreeMap"] = "TreeMap";
        ChartType["WordTree"] = "wordtree";
    })(exports.ChartType || (exports.ChartType = {}));

    var _a;
    var ChartTypesToPackages = (_a = {},
        _a[exports.ChartType.AnnotationChart] = 'annotationchart',
        _a[exports.ChartType.AreaChart] = 'corechart',
        _a[exports.ChartType.Bar] = 'bar',
        _a[exports.ChartType.BarChart] = 'corechart',
        _a[exports.ChartType.BubbleChart] = 'corechart',
        _a[exports.ChartType.Calendar] = 'calendar',
        _a[exports.ChartType.CandlestickChart] = 'corechart',
        _a[exports.ChartType.ColumnChart] = 'corechart',
        _a[exports.ChartType.ComboChart] = 'corechart',
        _a[exports.ChartType.PieChart] = 'corechart',
        _a[exports.ChartType.Gantt] = 'gantt',
        _a[exports.ChartType.Gauge] = 'gauge',
        _a[exports.ChartType.GeoChart] = 'geochart',
        _a[exports.ChartType.Histogram] = 'corechart',
        _a[exports.ChartType.Line] = 'line',
        _a[exports.ChartType.LineChart] = 'corechart',
        _a[exports.ChartType.Map] = 'map',
        _a[exports.ChartType.OrgChart] = 'orgchart',
        _a[exports.ChartType.Sankey] = 'sankey',
        _a[exports.ChartType.Scatter] = 'scatter',
        _a[exports.ChartType.ScatterChart] = 'corechart',
        _a[exports.ChartType.SteppedAreaChart] = 'corechart',
        _a[exports.ChartType.Table] = 'table',
        _a[exports.ChartType.Timeline] = 'timeline',
        _a[exports.ChartType.TreeMap] = 'treemap',
        _a[exports.ChartType.WordTree] = 'wordtree',
        _a);
    function getPackageForChart(type) {
        return ChartTypesToPackages[type];
    }
    function getDefaultConfig() {
        return {
            version: 'current',
            safeMode: false
        };
    }

    var GOOGLE_CHARTS_CONFIG = new i0.InjectionToken('GOOGLE_CHARTS_CONFIG');
    var GOOGLE_CHARTS_LAZY_CONFIG = new i0.InjectionToken('GOOGLE_CHARTS_LAZY_CONFIG', {
        providedIn: 'root',
        factory: function () {
            var configFromModule = i0.inject(GOOGLE_CHARTS_CONFIG, i0.InjectFlags.Optional);
            return rxjs.of(Object.assign(Object.assign({}, getDefaultConfig()), (configFromModule || {})));
        }
    });

    var ScriptLoaderService = /** @class */ (function () {
        function ScriptLoaderService(zone, localeId, config$) {
            this.zone = zone;
            this.localeId = localeId;
            this.config$ = config$;
            this.scriptSource = 'assets/js/charts/loader.js';
            this.scriptLoadSubject = new rxjs.Subject();
        }
        /**
         * Checks whether `google.charts` is available.
         *
         * If not, it can be loaded by calling `loadChartPackages`.
         *
         * @returns `true` if `google.charts` is available, `false` otherwise.
         */
        ScriptLoaderService.prototype.isGoogleChartsAvailable = function () {
            if (typeof google === 'undefined' || typeof google.charts === 'undefined') {
                return false;
            }
            return true;
        };
        /**
         * Loads the Google Chart script and the provided chart packages.
         * Can be called multiple times to load more packages.
         *
         * When called without any arguments, this will just load the default package
         * containing the namespaces `google.charts` and `google.visualization` without any charts.
         *
         * @param packages The packages to load.
         * @returns A stream emitting as soon as the chart packages are loaded.
         */
        ScriptLoaderService.prototype.loadChartPackages = function () {
            var _this = this;
            var packages = [];
            for (var _i = 0; _i < arguments.length; _i++) {
                packages[_i] = arguments[_i];
            }
            return this.loadGoogleCharts().pipe(operators.mergeMap(function () { return _this.config$; }), operators.map(function (config) {
                return Object.assign(Object.assign({}, getDefaultConfig()), (config || {}));
            }), operators.switchMap(function (googleChartsConfig) {
                return new rxjs.Observable(function (observer) {
                    var config = {
                        packages: packages,
                        language: _this.localeId,
                        mapsApiKey: googleChartsConfig.mapsApiKey,
                        safeMode: googleChartsConfig.safeMode
                    };
                    google.charts.load(googleChartsConfig.version, config);
                    google.charts.setOnLoadCallback(function () {
                        _this.zone.run(function () {
                            observer.next();
                            observer.complete();
                        });
                    });
                });
            }));
        };
        /**
         * Loads the Google Charts script. After the script is loaded, `google.charts` is defined.
         *
         * @returns A stream emitting as soon as loading has completed.
         * If the google charts script is already loaded, the stream emits immediately.
         */
        ScriptLoaderService.prototype.loadGoogleCharts = function () {
            var _this = this;
            if (this.isGoogleChartsAvailable()) {
                return rxjs.of(null);
            }
            else if (!this.isLoadingGoogleCharts()) {
                var script = this.createGoogleChartsScript();
                script.onload = function () {
                    _this.zone.run(function () {
                        _this.scriptLoadSubject.next();
                        _this.scriptLoadSubject.complete();
                    });
                };
                script.onerror = function () {
                    _this.zone.run(function () {
                        console.error('Failed to load the google charts script!');
                        _this.scriptLoadSubject.error(new Error('Failed to load the google charts script!'));
                    });
                };
            }
            return this.scriptLoadSubject.asObservable();
        };
        ScriptLoaderService.prototype.isLoadingGoogleCharts = function () {
            return this.getGoogleChartsScript() != null;
        };
        ScriptLoaderService.prototype.getGoogleChartsScript = function () {
            var _this = this;
            var pageScripts = Array.from(document.getElementsByTagName('script'));
            return pageScripts.find(function (script) { return script.src === _this.scriptSource; });
        };
        ScriptLoaderService.prototype.createGoogleChartsScript = function () {
            var script = document.createElement('script');
            script.type = 'text/javascript';
            script.src = this.scriptSource;
            script.async = true;
            document.getElementsByTagName('head')[0].appendChild(script);
            return script;
        };
        return ScriptLoaderService;
    }());
    ScriptLoaderService.decorators = [
        { type: i0.Injectable }
    ];
    ScriptLoaderService.ctorParameters = function () { return [
        { type: i0.NgZone },
        { type: String, decorators: [{ type: i0.Inject, args: [i0.LOCALE_ID,] }] },
        { type: rxjs.Observable, decorators: [{ type: i0.Inject, args: [GOOGLE_CHARTS_LAZY_CONFIG,] }] }
    ]; };

    /// <reference path="./types.ts" />
    var ChartEditorComponent = /** @class */ (function () {
        function ChartEditorComponent(scriptLoaderService) {
            this.scriptLoaderService = scriptLoaderService;
            this.initializedSubject = new rxjs.Subject();
        }
        Object.defineProperty(ChartEditorComponent.prototype, "initialized$", {
            /**
             * Emits as soon as the chart editor is fully initialized.
             */
            get: function () {
                return this.initializedSubject.asObservable();
            },
            enumerable: false,
            configurable: true
        });
        ChartEditorComponent.prototype.ngOnInit = function () {
            var _this = this;
            this.scriptLoaderService.loadChartPackages('charteditor').subscribe(function () {
                _this.editor = new google.visualization.ChartEditor();
                _this.initializedSubject.next(_this.editor);
                _this.initializedSubject.complete();
            });
        };
        ChartEditorComponent.prototype.editChart = function (component, options) {
            if (!component.chartWrapper) {
                throw new Error('Chart wrapper is `undefined`. Please wait for the `initialized$` observable before trying to edit a chart.');
            }
            if (!this.editor) {
                throw new Error('Chart editor is `undefined`. Please wait for the `initialized$` observable before trying to edit a chart.');
            }
            var handle = new ChartEditorRef(this.editor);
            this.editor.openDialog(component.chartWrapper, options || {});
            handle.afterClosed().subscribe(function (result) {
                if (result) {
                    component.chartWrapper = result;
                }
            });
            return handle;
        };
        return ChartEditorComponent;
    }());
    ChartEditorComponent.decorators = [
        { type: i0.Component, args: [{
                    selector: 'chart-editor',
                    template: "<ng-content></ng-content>",
                    host: { class: 'chart-editor' },
                    changeDetection: i0.ChangeDetectionStrategy.OnPush
                },] }
    ];
    ChartEditorComponent.ctorParameters = function () { return [
        { type: ScriptLoaderService }
    ]; };

    /*! *****************************************************************************
    Copyright (c) Microsoft Corporation.

    Permission to use, copy, modify, and/or distribute this software for any
    purpose with or without fee is hereby granted.

    THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES WITH
    REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY
    AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY SPECIAL, DIRECT,
    INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM
    LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR
    OTHER TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
    PERFORMANCE OF THIS SOFTWARE.
    ***************************************************************************** */
    /* global Reflect, Promise */
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b)
                if (Object.prototype.hasOwnProperty.call(b, p))
                    d[p] = b[p]; };
        return extendStatics(d, b);
    };
    function __extends(d, b) {
        if (typeof b !== "function" && b !== null)
            throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    }
    var __assign = function () {
        __assign = Object.assign || function __assign(t) {
            for (var s, i = 1, n = arguments.length; i < n; i++) {
                s = arguments[i];
                for (var p in s)
                    if (Object.prototype.hasOwnProperty.call(s, p))
                        t[p] = s[p];
            }
            return t;
        };
        return __assign.apply(this, arguments);
    };
    function __rest(s, e) {
        var t = {};
        for (var p in s)
            if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0)
                t[p] = s[p];
        if (s != null && typeof Object.getOwnPropertySymbols === "function")
            for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
                if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
                    t[p[i]] = s[p[i]];
            }
        return t;
    }
    function __decorate(decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function")
            r = Reflect.decorate(decorators, target, key, desc);
        else
            for (var i = decorators.length - 1; i >= 0; i--)
                if (d = decorators[i])
                    r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    }
    function __param(paramIndex, decorator) {
        return function (target, key) { decorator(target, key, paramIndex); };
    }
    function __metadata(metadataKey, metadataValue) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function")
            return Reflect.metadata(metadataKey, metadataValue);
    }
    function __awaiter(thisArg, _arguments, P, generator) {
        function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
        return new (P || (P = Promise))(function (resolve, reject) {
            function fulfilled(value) { try {
                step(generator.next(value));
            }
            catch (e) {
                reject(e);
            } }
            function rejected(value) { try {
                step(generator["throw"](value));
            }
            catch (e) {
                reject(e);
            } }
            function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
            step((generator = generator.apply(thisArg, _arguments || [])).next());
        });
    }
    function __generator(thisArg, body) {
        var _ = { label: 0, sent: function () { if (t[0] & 1)
                throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
        return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function () { return this; }), g;
        function verb(n) { return function (v) { return step([n, v]); }; }
        function step(op) {
            if (f)
                throw new TypeError("Generator is already executing.");
            while (_)
                try {
                    if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done)
                        return t;
                    if (y = 0, t)
                        op = [op[0] & 2, t.value];
                    switch (op[0]) {
                        case 0:
                        case 1:
                            t = op;
                            break;
                        case 4:
                            _.label++;
                            return { value: op[1], done: false };
                        case 5:
                            _.label++;
                            y = op[1];
                            op = [0];
                            continue;
                        case 7:
                            op = _.ops.pop();
                            _.trys.pop();
                            continue;
                        default:
                            if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) {
                                _ = 0;
                                continue;
                            }
                            if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) {
                                _.label = op[1];
                                break;
                            }
                            if (op[0] === 6 && _.label < t[1]) {
                                _.label = t[1];
                                t = op;
                                break;
                            }
                            if (t && _.label < t[2]) {
                                _.label = t[2];
                                _.ops.push(op);
                                break;
                            }
                            if (t[2])
                                _.ops.pop();
                            _.trys.pop();
                            continue;
                    }
                    op = body.call(thisArg, _);
                }
                catch (e) {
                    op = [6, e];
                    y = 0;
                }
                finally {
                    f = t = 0;
                }
            if (op[0] & 5)
                throw op[1];
            return { value: op[0] ? op[1] : void 0, done: true };
        }
    }
    var __createBinding = Object.create ? (function (o, m, k, k2) {
        if (k2 === undefined)
            k2 = k;
        Object.defineProperty(o, k2, { enumerable: true, get: function () { return m[k]; } });
    }) : (function (o, m, k, k2) {
        if (k2 === undefined)
            k2 = k;
        o[k2] = m[k];
    });
    function __exportStar(m, o) {
        for (var p in m)
            if (p !== "default" && !Object.prototype.hasOwnProperty.call(o, p))
                __createBinding(o, m, p);
    }
    function __values(o) {
        var s = typeof Symbol === "function" && Symbol.iterator, m = s && o[s], i = 0;
        if (m)
            return m.call(o);
        if (o && typeof o.length === "number")
            return {
                next: function () {
                    if (o && i >= o.length)
                        o = void 0;
                    return { value: o && o[i++], done: !o };
                }
            };
        throw new TypeError(s ? "Object is not iterable." : "Symbol.iterator is not defined.");
    }
    function __read(o, n) {
        var m = typeof Symbol === "function" && o[Symbol.iterator];
        if (!m)
            return o;
        var i = m.call(o), r, ar = [], e;
        try {
            while ((n === void 0 || n-- > 0) && !(r = i.next()).done)
                ar.push(r.value);
        }
        catch (error) {
            e = { error: error };
        }
        finally {
            try {
                if (r && !r.done && (m = i["return"]))
                    m.call(i);
            }
            finally {
                if (e)
                    throw e.error;
            }
        }
        return ar;
    }
    /** @deprecated */
    function __spread() {
        for (var ar = [], i = 0; i < arguments.length; i++)
            ar = ar.concat(__read(arguments[i]));
        return ar;
    }
    /** @deprecated */
    function __spreadArrays() {
        for (var s = 0, i = 0, il = arguments.length; i < il; i++)
            s += arguments[i].length;
        for (var r = Array(s), k = 0, i = 0; i < il; i++)
            for (var a = arguments[i], j = 0, jl = a.length; j < jl; j++, k++)
                r[k] = a[j];
        return r;
    }
    function __spreadArray(to, from, pack) {
        if (pack || arguments.length === 2)
            for (var i = 0, l = from.length, ar; i < l; i++) {
                if (ar || !(i in from)) {
                    if (!ar)
                        ar = Array.prototype.slice.call(from, 0, i);
                    ar[i] = from[i];
                }
            }
        return to.concat(ar || from);
    }
    function __await(v) {
        return this instanceof __await ? (this.v = v, this) : new __await(v);
    }
    function __asyncGenerator(thisArg, _arguments, generator) {
        if (!Symbol.asyncIterator)
            throw new TypeError("Symbol.asyncIterator is not defined.");
        var g = generator.apply(thisArg, _arguments || []), i, q = [];
        return i = {}, verb("next"), verb("throw"), verb("return"), i[Symbol.asyncIterator] = function () { return this; }, i;
        function verb(n) { if (g[n])
            i[n] = function (v) { return new Promise(function (a, b) { q.push([n, v, a, b]) > 1 || resume(n, v); }); }; }
        function resume(n, v) { try {
            step(g[n](v));
        }
        catch (e) {
            settle(q[0][3], e);
        } }
        function step(r) { r.value instanceof __await ? Promise.resolve(r.value.v).then(fulfill, reject) : settle(q[0][2], r); }
        function fulfill(value) { resume("next", value); }
        function reject(value) { resume("throw", value); }
        function settle(f, v) { if (f(v), q.shift(), q.length)
            resume(q[0][0], q[0][1]); }
    }
    function __asyncDelegator(o) {
        var i, p;
        return i = {}, verb("next"), verb("throw", function (e) { throw e; }), verb("return"), i[Symbol.iterator] = function () { return this; }, i;
        function verb(n, f) { i[n] = o[n] ? function (v) { return (p = !p) ? { value: __await(o[n](v)), done: n === "return" } : f ? f(v) : v; } : f; }
    }
    function __asyncValues(o) {
        if (!Symbol.asyncIterator)
            throw new TypeError("Symbol.asyncIterator is not defined.");
        var m = o[Symbol.asyncIterator], i;
        return m ? m.call(o) : (o = typeof __values === "function" ? __values(o) : o[Symbol.iterator](), i = {}, verb("next"), verb("throw"), verb("return"), i[Symbol.asyncIterator] = function () { return this; }, i);
        function verb(n) { i[n] = o[n] && function (v) { return new Promise(function (resolve, reject) { v = o[n](v), settle(resolve, reject, v.done, v.value); }); }; }
        function settle(resolve, reject, d, v) { Promise.resolve(v).then(function (v) { resolve({ value: v, done: d }); }, reject); }
    }
    function __makeTemplateObject(cooked, raw) {
        if (Object.defineProperty) {
            Object.defineProperty(cooked, "raw", { value: raw });
        }
        else {
            cooked.raw = raw;
        }
        return cooked;
    }
    ;
    var __setModuleDefault = Object.create ? (function (o, v) {
        Object.defineProperty(o, "default", { enumerable: true, value: v });
    }) : function (o, v) {
        o["default"] = v;
    };
    function __importStar(mod) {
        if (mod && mod.__esModule)
            return mod;
        var result = {};
        if (mod != null)
            for (var k in mod)
                if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k))
                    __createBinding(result, mod, k);
        __setModuleDefault(result, mod);
        return result;
    }
    function __importDefault(mod) {
        return (mod && mod.__esModule) ? mod : { default: mod };
    }
    function __classPrivateFieldGet(receiver, state, kind, f) {
        if (kind === "a" && !f)
            throw new TypeError("Private accessor was defined without a getter");
        if (typeof state === "function" ? receiver !== state || !f : !state.has(receiver))
            throw new TypeError("Cannot read private member from an object whose class did not declare it");
        return kind === "m" ? f : kind === "a" ? f.call(receiver) : f ? f.value : state.get(receiver);
    }
    function __classPrivateFieldSet(receiver, state, value, kind, f) {
        if (kind === "m")
            throw new TypeError("Private method is not writable");
        if (kind === "a" && !f)
            throw new TypeError("Private accessor was defined without a setter");
        if (typeof state === "function" ? receiver !== state || !f : !state.has(receiver))
            throw new TypeError("Cannot write private member to an object whose class did not declare it");
        return (kind === "a" ? f.call(receiver, value) : f ? f.value = value : state.set(receiver, value)), value;
    }

    var DataTableService = /** @class */ (function () {
        function DataTableService() {
        }
        DataTableService.prototype.create = function (data, columns, formatters) {
            if (data == null) {
                return undefined;
            }
            var firstRowIsData = true;
            if (columns != null) {
                firstRowIsData = false;
            }
            var dataTable = google.visualization.arrayToDataTable(this.getDataAsTable(data, columns), firstRowIsData);
            if (formatters) {
                this.applyFormatters(dataTable, formatters);
            }
            return dataTable;
        };
        DataTableService.prototype.getDataAsTable = function (data, columns) {
            if (columns) {
                return __spreadArray([columns], __read(data));
            }
            else {
                return data;
            }
        };
        DataTableService.prototype.applyFormatters = function (dataTable, formatters) {
            var e_1, _a;
            try {
                for (var formatters_1 = __values(formatters), formatters_1_1 = formatters_1.next(); !formatters_1_1.done; formatters_1_1 = formatters_1.next()) {
                    var val = formatters_1_1.value;
                    val.formatter.format(dataTable, val.colIndex);
                }
            }
            catch (e_1_1) { e_1 = { error: e_1_1 }; }
            finally {
                try {
                    if (formatters_1_1 && !formatters_1_1.done && (_a = formatters_1.return)) _a.call(formatters_1);
                }
                finally { if (e_1) throw e_1.error; }
            }
        };
        return DataTableService;
    }());
    DataTableService.ɵprov = i0__namespace.ɵɵdefineInjectable({ factory: function DataTableService_Factory() { return new DataTableService(); }, token: DataTableService, providedIn: "root" });
    DataTableService.decorators = [
        { type: i0.Injectable, args: [{ providedIn: 'root' },] }
    ];

    /**
     * Generates a random ID which can be used to uniquely identify an element.
     */
    function generateRandomId() {
        // Math.random should be unique because of its seeding algorithm.
        // Convert it to base 36 (numbers + letters), and grab the first 9 characters
        // after the decimal.
        return '_' + Math.random().toString(36).substr(2, 9);
    }

    var ControlWrapperComponent = /** @class */ (function () {
        function ControlWrapperComponent(loaderService) {
            this.loaderService = loaderService;
            /**
             * Emits when an error occurs when attempting to render the control.
             */
            this.error = new i0.EventEmitter();
            /**
             * The control is ready to accept user interaction and for external method calls.
             *
             * Alternatively, you can listen for a ready event on the dashboard holding the control
             * and call control methods only after the event was fired.
             */
            this.ready = new i0.EventEmitter();
            /**
             * Emits when the user interacts with the control, affecting its state.
             * For example, a `stateChange` event will be emitted whenever you move the thumbs of a range slider control.
             *
             * To retrieve an updated control state after the event fired, call `ControlWrapper.getState()`.
             */
            this.stateChange = new i0.EventEmitter();
            /**
             * A generated id assigned to this components DOM element.
             */
            this.id = generateRandomId();
            this.wrapperReadySubject = new rxjs.ReplaySubject(1);
        }
        Object.defineProperty(ControlWrapperComponent.prototype, "wrapperReady$", {
            /**
             * Emits after the `ControlWrapper` was created.
             */
            get: function () {
                return this.wrapperReadySubject.asObservable();
            },
            enumerable: false,
            configurable: true
        });
        Object.defineProperty(ControlWrapperComponent.prototype, "controlWrapper", {
            get: function () {
                if (!this._controlWrapper) {
                    throw new Error("Cannot access the control wrapper before it being initialized.");
                }
                return this._controlWrapper;
            },
            enumerable: false,
            configurable: true
        });
        ControlWrapperComponent.prototype.ngOnInit = function () {
            var _this = this;
            this.loaderService.loadChartPackages('controls').subscribe(function () {
                _this.createControlWrapper();
            });
        };
        ControlWrapperComponent.prototype.ngOnChanges = function (changes) {
            if (!this._controlWrapper) {
                return;
            }
            if (changes.type) {
                this._controlWrapper.setControlType(this.type);
            }
            if (changes.options) {
                this._controlWrapper.setOptions(this.options || {});
            }
            if (changes.state) {
                this._controlWrapper.setState(this.state || {});
            }
        };
        ControlWrapperComponent.prototype.createControlWrapper = function () {
            this._controlWrapper = new google.visualization.ControlWrapper({
                containerId: this.id,
                controlType: this.type,
                state: this.state,
                options: this.options
            });
            this.addEventListeners();
            this.wrapperReadySubject.next(this._controlWrapper);
        };
        ControlWrapperComponent.prototype.addEventListeners = function () {
            var _this = this;
            google.visualization.events.removeAllListeners(this._controlWrapper);
            google.visualization.events.addListener(this._controlWrapper, 'ready', function (event) { return _this.ready.emit(event); });
            google.visualization.events.addListener(this._controlWrapper, 'error', function (event) { return _this.error.emit(event); });
            google.visualization.events.addListener(this._controlWrapper, 'statechange', function (event) { return _this.stateChange.emit(event); });
        };
        return ControlWrapperComponent;
    }());
    ControlWrapperComponent.decorators = [
        { type: i0.Component, args: [{
                    selector: 'control-wrapper',
                    template: '',
                    host: { class: 'control-wrapper' },
                    exportAs: 'controlWrapper',
                    changeDetection: i0.ChangeDetectionStrategy.OnPush
                },] }
    ];
    ControlWrapperComponent.ctorParameters = function () { return [
        { type: ScriptLoaderService }
    ]; };
    ControlWrapperComponent.propDecorators = {
        for: [{ type: i0.Input }],
        type: [{ type: i0.Input }],
        options: [{ type: i0.Input }],
        state: [{ type: i0.Input }],
        error: [{ type: i0.Output }],
        ready: [{ type: i0.Output }],
        stateChange: [{ type: i0.Output }],
        id: [{ type: i0.HostBinding, args: ['id',] }]
    };

    var DashboardComponent = /** @class */ (function () {
        function DashboardComponent(element, loaderService, dataTableService) {
            this.element = element;
            this.loaderService = loaderService;
            this.dataTableService = dataTableService;
            /**
             * The dashboard has completed drawing and is ready to accept changes.
             *
             * The ready event will also fire:
             * - after the completion of a dashboard refresh triggered by a user or programmatic interaction with one of the controls,
             * - after redrawing any chart on the dashboard.
             */
            this.ready = new i0.EventEmitter();
            /**
             * Emits when an error occurs when attempting to render the dashboard.
             * One or more of the controls and charts that are part of the dashboard may have failed rendering.
             */
            this.error = new i0.EventEmitter();
            this.initialized = false;
        }
        DashboardComponent.prototype.ngOnInit = function () {
            var _this = this;
            this.loaderService.loadChartPackages('controls').subscribe(function () {
                _this.dataTable = _this.dataTableService.create(_this.data, _this.columns, _this.formatters);
                _this.createDashboard();
                _this.initialized = true;
            });
        };
        DashboardComponent.prototype.ngOnChanges = function (changes) {
            if (!this.initialized) {
                return;
            }
            if (changes.data || changes.columns || changes.formatters) {
                this.dataTable = this.dataTableService.create(this.data, this.columns, this.formatters);
                this.dashboard.draw(this.dataTable);
            }
        };
        DashboardComponent.prototype.createDashboard = function () {
            var _this = this;
            // TODO: This should happen in the control wrapper
            // However, I don't yet know how to do this because then `bind()` would get called multiple times
            // for the same control if something changes. This is not supported by google charts as far as I can tell
            // from their source code.
            var controlWrappersReady$ = this.controlWrappers.map(function (control) { return control.wrapperReady$; });
            var chartsReady$ = this.controlWrappers
                .map(function (control) { return control.for; })
                .map(function (charts) {
                if (Array.isArray(charts)) {
                    // CombineLatest waits for all observables
                    return rxjs.combineLatest(charts.map(function (chart) { return chart.wrapperReady$; }));
                }
                else {
                    return charts.wrapperReady$;
                }
            });
            // We have to wait for all chart wrappers and control wrappers to be initialized
            // before we can compose them together to create the dashboard
            rxjs.combineLatest(__spreadArray(__spreadArray([], __read(controlWrappersReady$)), __read(chartsReady$))).subscribe(function () {
                _this.dashboard = new google.visualization.Dashboard(_this.element.nativeElement);
                _this.initializeBindings();
                _this.registerEvents();
                _this.dashboard.draw(_this.dataTable);
            });
        };
        DashboardComponent.prototype.registerEvents = function () {
            var _this = this;
            google.visualization.events.removeAllListeners(this.dashboard);
            var registerDashEvent = function (object, eventName, callback) {
                google.visualization.events.addListener(object, eventName, callback);
            };
            registerDashEvent(this.dashboard, 'ready', function () { return _this.ready.emit(); });
            registerDashEvent(this.dashboard, 'error', function (error) { return _this.error.emit(error); });
        };
        DashboardComponent.prototype.initializeBindings = function () {
            var _this = this;
            this.controlWrappers.forEach(function (control) {
                if (Array.isArray(control.for)) {
                    var chartWrappers = control.for.map(function (chart) { return chart.chartWrapper; });
                    _this.dashboard.bind(control.controlWrapper, chartWrappers);
                }
                else {
                    _this.dashboard.bind(control.controlWrapper, control.for.chartWrapper);
                }
            });
        };
        return DashboardComponent;
    }());
    DashboardComponent.decorators = [
        { type: i0.Component, args: [{
                    selector: 'dashboard',
                    template: '<ng-content></ng-content>',
                    changeDetection: i0.ChangeDetectionStrategy.OnPush,
                    exportAs: 'dashboard',
                    host: { class: 'dashboard' }
                },] }
    ];
    DashboardComponent.ctorParameters = function () { return [
        { type: i0.ElementRef },
        { type: ScriptLoaderService },
        { type: DataTableService }
    ]; };
    DashboardComponent.propDecorators = {
        data: [{ type: i0.Input }],
        columns: [{ type: i0.Input }],
        formatters: [{ type: i0.Input }],
        ready: [{ type: i0.Output }],
        error: [{ type: i0.Output }],
        controlWrappers: [{ type: i0.ContentChildren, args: [ControlWrapperComponent,] }]
    };

    var GoogleChartComponent = /** @class */ (function () {
        function GoogleChartComponent(element, scriptLoaderService, dataTableService, dashboard) {
            this.element = element;
            this.scriptLoaderService = scriptLoaderService;
            this.dataTableService = dataTableService;
            this.dashboard = dashboard;
            /**
             * The chart-specific options. All options listen in the Google Charts documentation applying
             * to the chart type specified can be used here.
             */
            this.options = {};
            /**
             * If this is set to `true`, the chart will be redrawn if the browser window is resized.
             * Defaults to `false` and should only be used when specifying the width or height of the chart
             * in percent.
             *
             * Note that this can impact performance.
             */
            this.dynamicResize = false;
            this.ready = new i0.EventEmitter();
            this.error = new i0.EventEmitter();
            this.select = new i0.EventEmitter();
            this.mouseover = new i0.EventEmitter();
            this.mouseleave = new i0.EventEmitter();
            this.wrapperReadySubject = new rxjs.ReplaySubject(1);
            this.initialized = false;
            this.eventListeners = new Map();
        }
        Object.defineProperty(GoogleChartComponent.prototype, "chart", {
            get: function () {
                return this.chartWrapper.getChart();
            },
            enumerable: false,
            configurable: true
        });
        Object.defineProperty(GoogleChartComponent.prototype, "wrapperReady$", {
            get: function () {
                return this.wrapperReadySubject.asObservable();
            },
            enumerable: false,
            configurable: true
        });
        Object.defineProperty(GoogleChartComponent.prototype, "chartWrapper", {
            get: function () {
                if (!this.wrapper) {
                    throw new Error('Trying to access the chart wrapper before it was fully initialized');
                }
                return this.wrapper;
            },
            set: function (wrapper) {
                this.wrapper = wrapper;
                this.drawChart();
            },
            enumerable: false,
            configurable: true
        });
        GoogleChartComponent.prototype.ngOnInit = function () {
            var _this = this;
            // We don't need to load any chart packages, the chart wrapper will handle this for us
            this.scriptLoaderService.loadChartPackages(getPackageForChart(this.type)).subscribe(function () {
                _this.dataTable = _this.dataTableService.create(_this.data, _this.columns, _this.formatters);
                // Only ever create the wrapper once to allow animations to happen when something changes.
                _this.wrapper = new google.visualization.ChartWrapper({
                    container: _this.element.nativeElement,
                    chartType: _this.type,
                    dataTable: _this.dataTable,
                    options: _this.mergeOptions()
                });
                _this.registerChartEvents();
                _this.wrapperReadySubject.next(_this.wrapper);
                _this.initialized = true;
                _this.drawChart();
            });
        };
        GoogleChartComponent.prototype.ngOnChanges = function (changes) {
            if (changes.dynamicResize) {
                this.updateResizeListener();
            }
            if (this.initialized) {
                var shouldRedraw = false;
                if (changes.data || changes.columns || changes.formatters) {
                    this.dataTable = this.dataTableService.create(this.data, this.columns, this.formatters);
                    this.wrapper.setDataTable(this.dataTable);
                    shouldRedraw = true;
                }
                if (changes.type) {
                    this.wrapper.setChartType(this.type);
                    shouldRedraw = true;
                }
                if (changes.options || changes.width || changes.height || changes.title) {
                    this.wrapper.setOptions(this.mergeOptions());
                    shouldRedraw = true;
                }
                if (shouldRedraw) {
                    this.drawChart();
                }
            }
        };
        GoogleChartComponent.prototype.ngOnDestroy = function () {
            this.unsubscribeToResizeIfSubscribed();
        };
        /**
         * For listening to events other than the most common ones (available via Output properties).
         *
         * Can be called after the chart emits that it's "ready".
         *
         * Returns a handle that can be used for `removeEventListener`.
         */
        GoogleChartComponent.prototype.addEventListener = function (eventName, callback) {
            var handle = this.registerChartEvent(this.chart, eventName, callback);
            this.eventListeners.set(handle, { eventName: eventName, callback: callback, handle: handle });
            return handle;
        };
        GoogleChartComponent.prototype.removeEventListener = function (handle) {
            var entry = this.eventListeners.get(handle);
            if (entry) {
                google.visualization.events.removeListener(entry.handle);
                this.eventListeners.delete(handle);
            }
        };
        GoogleChartComponent.prototype.updateResizeListener = function () {
            var _this = this;
            this.unsubscribeToResizeIfSubscribed();
            if (this.dynamicResize) {
                this.resizeSubscription = rxjs.fromEvent(window, 'resize', { passive: true })
                    .pipe(operators.debounceTime(100))
                    .subscribe(function () {
                    if (_this.initialized) {
                        _this.drawChart();
                    }
                });
            }
        };
        GoogleChartComponent.prototype.unsubscribeToResizeIfSubscribed = function () {
            if (this.resizeSubscription != null) {
                this.resizeSubscription.unsubscribe();
                this.resizeSubscription = undefined;
            }
        };
        GoogleChartComponent.prototype.mergeOptions = function () {
            return Object.assign({ title: this.title, width: this.width, height: this.height }, this.options);
        };
        GoogleChartComponent.prototype.registerChartEvents = function () {
            var _this = this;
            google.visualization.events.removeAllListeners(this.wrapper);
            this.registerChartEvent(this.wrapper, 'ready', function () {
                // This could also be done by checking if we already subscribed to the events
                google.visualization.events.removeAllListeners(_this.chart);
                _this.registerChartEvent(_this.chart, 'onmouseover', function (event) { return _this.mouseover.emit(event); });
                _this.registerChartEvent(_this.chart, 'onmouseout', function (event) { return _this.mouseleave.emit(event); });
                _this.registerChartEvent(_this.chart, 'select', function () {
                    var selection = _this.chart.getSelection();
                    _this.select.emit({ selection: selection });
                });
                _this.eventListeners.forEach(function (x) { return (x.handle = _this.registerChartEvent(_this.chart, x.eventName, x.callback)); });
                _this.ready.emit({ chart: _this.chart });
            });
            this.registerChartEvent(this.wrapper, 'error', function (error) { return _this.error.emit(error); });
        };
        GoogleChartComponent.prototype.registerChartEvent = function (object, eventName, callback) {
            return google.visualization.events.addListener(object, eventName, callback);
        };
        GoogleChartComponent.prototype.drawChart = function () {
            if (this.dashboard != null) {
                // If this chart is part of a dashboard, the dashboard takes care of drawing
                return;
            }
            this.wrapper.draw();
        };
        return GoogleChartComponent;
    }());
    GoogleChartComponent.decorators = [
        { type: i0.Component, args: [{
                    selector: 'google-chart',
                    template: '',
                    host: { class: 'google-chart' },
                    exportAs: 'googleChart',
                    changeDetection: i0.ChangeDetectionStrategy.OnPush,
                    styles: [':host { width: fit-content; display: block; }']
                },] }
    ];
    GoogleChartComponent.ctorParameters = function () { return [
        { type: i0.ElementRef },
        { type: ScriptLoaderService },
        { type: DataTableService },
        { type: DashboardComponent, decorators: [{ type: i0.Optional }] }
    ]; };
    GoogleChartComponent.propDecorators = {
        type: [{ type: i0.Input }],
        data: [{ type: i0.Input }],
        columns: [{ type: i0.Input }],
        title: [{ type: i0.Input }],
        width: [{ type: i0.Input }],
        height: [{ type: i0.Input }],
        options: [{ type: i0.Input }],
        formatters: [{ type: i0.Input }],
        dynamicResize: [{ type: i0.Input }],
        ready: [{ type: i0.Output }],
        error: [{ type: i0.Output }],
        select: [{ type: i0.Output }],
        mouseover: [{ type: i0.Output }],
        mouseleave: [{ type: i0.Output }]
    };

    var ChartWrapperComponent = /** @class */ (function () {
        function ChartWrapperComponent(element, scriptLoaderService) {
            this.element = element;
            this.scriptLoaderService = scriptLoaderService;
            this.error = new i0.EventEmitter();
            this.ready = new i0.EventEmitter();
            this.select = new i0.EventEmitter();
            this.wrapperReadySubject = new rxjs.ReplaySubject(1);
            this.initialized = false;
        }
        Object.defineProperty(ChartWrapperComponent.prototype, "chart", {
            get: function () {
                return this.chartWrapper.getChart();
            },
            enumerable: false,
            configurable: true
        });
        Object.defineProperty(ChartWrapperComponent.prototype, "wrapperReady$", {
            get: function () {
                return this.wrapperReadySubject.asObservable();
            },
            enumerable: false,
            configurable: true
        });
        Object.defineProperty(ChartWrapperComponent.prototype, "chartWrapper", {
            get: function () {
                if (!this.wrapper) {
                    throw new Error('Cannot access the chart wrapper before initialization.');
                }
                return this.wrapper;
            },
            set: function (wrapper) {
                this.wrapper = wrapper;
                this.drawChart();
            },
            enumerable: false,
            configurable: true
        });
        ChartWrapperComponent.prototype.ngOnInit = function () {
            var _this = this;
            // We don't need to load any chart packages, the chart wrapper will handle this else for us
            this.scriptLoaderService.loadChartPackages().subscribe(function () {
                if (!_this.specs) {
                    _this.specs = {};
                }
                var _a = _this.specs, containerId = _a.containerId, container = _a.container, specs = __rest(_a, ["containerId", "container"]);
                // Only ever create the wrapper once to allow animations to happen if something changes.
                _this.wrapper = new google.visualization.ChartWrapper(Object.assign(Object.assign({}, specs), { container: _this.element.nativeElement }));
                _this.registerChartEvents();
                _this.wrapperReadySubject.next(_this.wrapper);
                _this.drawChart();
                _this.initialized = true;
            });
        };
        ChartWrapperComponent.prototype.ngOnChanges = function (changes) {
            if (!this.initialized) {
                return;
            }
            if (changes.specs) {
                this.updateChart();
                this.drawChart();
            }
        };
        ChartWrapperComponent.prototype.updateChart = function () {
            if (!this.specs) {
                // When creating the wrapper with empty specs, the google charts library will show an error
                // If we don't do this, a javascript error will be thrown, which is not as visible to the user
                this.specs = {};
            }
            // The typing here are not correct. These methods accept `undefined` as well.
            // That's why we have to cast to `any`
            this.wrapper.setChartType(this.specs.chartType);
            this.wrapper.setDataTable(this.specs.dataTable);
            this.wrapper.setDataSourceUrl(this.specs.dataSourceUrl);
            this.wrapper.setDataSourceUrl(this.specs.dataSourceUrl);
            this.wrapper.setQuery(this.specs.query);
            this.wrapper.setOptions(this.specs.options);
            this.wrapper.setRefreshInterval(this.specs.refreshInterval);
            this.wrapper.setView(this.specs.view);
        };
        ChartWrapperComponent.prototype.drawChart = function () {
            if (this.wrapper) {
                this.wrapper.draw();
            }
        };
        ChartWrapperComponent.prototype.registerChartEvents = function () {
            var _this = this;
            google.visualization.events.removeAllListeners(this.wrapper);
            var registerChartEvent = function (object, eventName, callback) {
                google.visualization.events.addListener(object, eventName, callback);
            };
            registerChartEvent(this.wrapper, 'ready', function () { return _this.ready.emit({ chart: _this.chart }); });
            registerChartEvent(this.wrapper, 'error', function (error) { return _this.error.emit(error); });
            registerChartEvent(this.wrapper, 'select', function () {
                var selection = _this.chart.getSelection();
                _this.select.emit({ selection: selection });
            });
        };
        return ChartWrapperComponent;
    }());
    ChartWrapperComponent.decorators = [
        { type: i0.Component, args: [{
                    selector: 'chart-wrapper',
                    template: '',
                    host: { class: 'chart-wrapper' },
                    exportAs: 'chartWrapper',
                    changeDetection: i0.ChangeDetectionStrategy.OnPush,
                    styles: [':host { width: fit-content; display: block; }']
                },] }
    ];
    ChartWrapperComponent.ctorParameters = function () { return [
        { type: i0.ElementRef },
        { type: ScriptLoaderService }
    ]; };
    ChartWrapperComponent.propDecorators = {
        specs: [{ type: i0.Input }],
        error: [{ type: i0.Output }],
        ready: [{ type: i0.Output }],
        select: [{ type: i0.Output }]
    };

    exports.FilterType = void 0;
    (function (FilterType) {
        FilterType["Category"] = "CategoryFilter";
        FilterType["ChartRange"] = "ChartRangeFilter";
        FilterType["DateRange"] = "DateRangeFilter";
        FilterType["NumberRange"] = "NumberRangeFilter";
        FilterType["String"] = "StringFilter";
    })(exports.FilterType || (exports.FilterType = {}));

    var GoogleChartsModule = /** @class */ (function () {
        function GoogleChartsModule() {
        }
        GoogleChartsModule.forRoot = function (config) {
            if (config === void 0) { config = {}; }
            return {
                ngModule: GoogleChartsModule,
                providers: [{ provide: GOOGLE_CHARTS_CONFIG, useValue: config }]
            };
        };
        return GoogleChartsModule;
    }());
    GoogleChartsModule.decorators = [
        { type: i0.NgModule, args: [{
                    declarations: [
                        GoogleChartComponent,
                        ChartWrapperComponent,
                        DashboardComponent,
                        ControlWrapperComponent,
                        ChartEditorComponent
                    ],
                    providers: [ScriptLoaderService],
                    exports: [
                        GoogleChartComponent,
                        ChartWrapperComponent,
                        DashboardComponent,
                        ControlWrapperComponent,
                        ChartEditorComponent
                    ]
                },] }
    ];

    /*
     * Public API Surface of angular-google-charts
     */

    /**
     * Generated bundle index. Do not edit.
     */

    exports.ChartEditorComponent = ChartEditorComponent;
    exports.ChartEditorRef = ChartEditorRef;
    exports.ChartWrapperComponent = ChartWrapperComponent;
    exports.ControlWrapperComponent = ControlWrapperComponent;
    exports.DashboardComponent = DashboardComponent;
    exports.GOOGLE_CHARTS_CONFIG = GOOGLE_CHARTS_CONFIG;
    exports.GOOGLE_CHARTS_LAZY_CONFIG = GOOGLE_CHARTS_LAZY_CONFIG;
    exports.GoogleChartComponent = GoogleChartComponent;
    exports.GoogleChartsModule = GoogleChartsModule;
    exports.ScriptLoaderService = ScriptLoaderService;
    exports.getDefaultConfig = getDefaultConfig;
    exports.getPackageForChart = getPackageForChart;
    exports.ɵa = DataTableService;

    Object.defineProperty(exports, '__esModule', { value: true });

})));
//# sourceMappingURL=angular-google-charts.umd.js.map
