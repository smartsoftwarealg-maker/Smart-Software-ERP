/**
 * Generated bundle index. Do not edit.
 */
export * from './index';
export { DataTableService as ɵa } from './lib/services/data-table.service';
